
// package.view;

class MainMenuScreen extends JFrame
{
    private JPanel mainMenuTitle;
    private JPanel mainMenuButtons;
    private Controller ctnl;
    private FrmSelect ts;
    private FrmInstructions instructions;
    
    public MainMenuScreen(Controller ctnl)
    {
        this.ctnl = ctnl;
        initMainMenuComponents();
    }
    
    private void initMainMenuComponents() 
    {
        setTitle("The Tank Game");
        setSize(800, 600);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        mainMenuTitle = new JPanel(new GridLayout(1, 1));
        mainMenuTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        
        JLabel title = new JLabel("The Tank Game");
        title.setFont(new java.awt.Font("Times New Roman", 1, 64));
        title.setForeground(Color.red);
        
        mainMenuTitle.add(title);
        
        mainMenuButtons = new JPanel(new GridLayout(4, 1));
        mainMenuButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        JButton play = new JButton("Play");
        play.setPreferredSize(new Dimension(200, 100));
        play.addActionListener(event -> Play());
        mainMenuButtons.add(play);
        
        JButton instructions = new JButton("Instructions");
        instructions.setPreferredSize(new Dimension(200, 100));
        instructions.addActionListener(event -> Instructions());
        mainMenuButtons.add(instructions);
        
        JButton exit = new JButton("Exit");
        exit.setPreferredSize(new Dimension(200, 100));
        exit.addActionListener(event -> ExitM());
        mainMenuButtons.add(exit);
        
        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(mainMenuTitle, BorderLayout.CENTER);
        getContentPane().add(mainMenuButtons, BorderLayout.SOUTH);
    }
    
    public void ExitM()
    {
        System.exit(0);
    }
    
    public void Play()
    {
        ts = new FrmSelect(ctnl);
        ts.setVisible(true);
        this.setVisible(false);
    }
    
    public void Instructions()
    {
        instructions = new FrmInstructions(ctnl);
        this.setVisible(false);
        instructions.setVisible(true);
    }
    
    public void instructionsBack()
    {
        instructions.setVisible(false);
        this.setVisible(true);
    }
}
