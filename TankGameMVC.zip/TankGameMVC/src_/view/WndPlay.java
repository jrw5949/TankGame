
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

class WndPlay extends JFrame
{
     
    public WndPlay()
    {
        intComponents();
    }
    
    private void intComponents()
    {
        setTitle("Level 1");
        setSize(1000, 1000);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setContentPane(new JPanel(new BorderLayout()));
    }

    public static void main(String[] args) {
        WndPlay wndplay = new WndPlay();
        wndplay.setVisible(true);
    }
}
