
package model;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.util.ArrayList;
import java.io.File;

public class Tank extends TTank
{
  private String dirResourcePath = "./tanks/T-34";
  private ArrayList<ImageIcon> arlImg = null;
  private JLabel img = null;
  private Color speedLblColor = Color.black;
  private Color shutLblColor = Color.black;
  private static int imgCount = 4;

  public Tank(){
    super();
    loadImagesSetDefault();
    return;
  }//Tank.end

  public Tank(File path){
    return;
  }

  public Tank(
    String name
  , double maxSpeed
  , double shutSpeed
  , String dirResourcePath
  ){
    super(name, maxSpeed, shutSpeed);
    this.dirResourcePath = dirResourcePath;
    loadImagesSetDefault();
  }

  public Tank(
    String name
  , double maxSpeed
  , double shutSpeed
  ){
    this(name, maxSpeed, shutSpeed, "./tanks/" + name);
  }
  
  public Color getSpeedLblColor()
  {
    return speedLblColor;
  }
  
  public Color getShutLblColor()
  {
    return shutLblColor ;
  }

  public void setSpeedLblColor(Color color)
  {
    this.speedLblColor = color;
    return;
  }
  
  public void setShutLblColor(Color color)
  {
    this.shutLblColor = color;
  }
  public void loadImagesSetDefault()
  {
    this.arlImg = new ArrayList<ImageIcon>();  
    String path = "";
    // Paths should be obtained directly from the directory structure
    for(int pstn=1; pstn <= imgCount; pstn++) {
      path = String.format(dirResourcePath + "/%d.gif", pstn*100);
      arlImg.add(new ImageIcon(path));
    }
    img = new JLabel(arlImg.get(0));
    return;
  }

  public ArrayList<ImageIcon> getImg()
  {
    return arlImg;
  }

  public ImageIcon getImg(int img)
  {
    // add loging to validate the input parameter
    return arlImg.get(img);
  }

  @Override
  public void printInfo()
  {
    super.printInfo();
    System.out.printf("%nsize()    : %d", arlImg.size());
    System.out.print("\n::");
    for(int idx=0; idx < getImg().size(); idx++) {
      System.out.print("\n" + getImg().get(idx));
    }
  }

}
