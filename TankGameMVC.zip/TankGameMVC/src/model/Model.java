
package model;

import java.util.ArrayList;
import java.awt.Color;

public class Model 
{
  ArrayList<Tank> tanks = null;

  public Model()
  {
    int t=0;
    
    tanks = new ArrayList<Tank>();

    t=0;
    tanks.add(new Tank("Hotchkiss", 5, 2));
    tanks.get(t).setMaxSpeedq("Fast");
    tanks.get(t).setShutSpeedq("Slow");
    tanks.get(t).setSpeedLblColor(Color.green);
    tanks.get(t).setShutLblColor(Color.red);

    t++;
    tanks.add(new Tank("Panther", 2, 5));
    tanks.get(t).setMaxSpeedq("Slow");
    tanks.get(t).setShutSpeedq("Fast");
    tanks.get(t).setSpeedLblColor(Color.red);
    tanks.get(t).setShutLblColor(Color.green);

    t++;
    tanks.add(new Tank("T-34", 4, 3));
    tanks.get(t).setMaxSpeedq("Medium");
    tanks.get(t).setShutSpeedq("Medium");
    tanks.get(t).setSpeedLblColor(Color.orange);
    tanks.get(t).setShutLblColor(Color.orange);

    t++;
    tanks.add(new Tank("Panzer VI", 3, 4, "./tanks/PanzerVI"));
    tanks.get(t).setMaxSpeedq("Medium-Slow");
    tanks.get(t).setShutSpeedq("Medium-Fast");
    tanks.get(t).setSpeedLblColor(Color.yellow);
    tanks.get(t).setShutLblColor(Color.yellow);

  }

  public ArrayList<Tank> getTanksSpecs()
  {
    return tanks;
  }

}
