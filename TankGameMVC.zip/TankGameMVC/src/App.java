// Jake White
// jrw5949

import controller.Controller;
import view.View;
import model.Model;

public class App
{
  public static void main(String[] args) 
  {
    View view = new View();
    Model model = new Model();
    Controller controller = new Controller(model, view);
    return;
  }
}

//Testing/functionality plan: https://github.com/jrw5949/TankGame/blob/master/Project%20Deliverable%203%20functionality%20and%20testing%20plan.docx

//Functionality: The tank must be able to fire ammunition of a bullet in the direction the tank is facing. Depending on the tank chosen the bullet speed 
//must be increased or decreased based on the tank type.The background or terrain must be changed to the selected background such as a grass field.The system 
//must be able to play a sound when the user chooses to fire a bullet by pressing the fire key.Enemy tanks are spawned around the border of the map and are shooting 
//in the direction that they are facing. Add a timer that counts down, the goal of the game is to shoot and destroy the enemy tanks before time runs out. If the time 
//runs out before all tanks are destroyed a message will pop up saying you lost. If you destroy the tanks before the timer runs out it will display you win. If a bullet 
//hits your tank the loss message will pop up.

//Testing:
//When space bar is pressed a sound is played. �
//All tanks spawn correctly and are shooting. The background is a grassy battlefield. �
//If shot the game ends. If timer runs out and enemies are still alive you lose. If you destroy all tanks before timer runs out you win.Upon pressing the fire key the bullet speed should be faster or slower based on the tank type.A bullet should be fired from the tank in the direction that the tank is facing
//If another tank is hit, the opposing tank should be destroyed
//Upon firing a sound should be played when the space bar is pressed.