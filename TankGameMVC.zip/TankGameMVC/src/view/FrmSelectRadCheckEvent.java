
package view;

class FrmSelectRadCheckEvent
{
  private FrmSelect frame;// probably static?
  private int index;

  //....................................................................
  public FrmSelectRadCheckEvent(FrmSelect frame, int index)
  {
    this.frame = frame;
    this.index = index;
  }

  //....................................................................
  public void select()
  {
    frame.setSelectedIndex(index);
    frame.setSelectedTank(frame.getTanks().get(index));
  }

}
