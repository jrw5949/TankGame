
package view;

import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import java.awt.Color;
import java.awt.Dimension;

class FrmMain extends JFrame
{
  private View view;
  private JPanel pnlTitle;
  private JPanel pnlButtons;
  
  public FrmMain(View view)
  {
    this.view = view;
    initMainMenuComponents();
  }
  
  private void initMainMenuComponents() 
  {
    setTitle("Main Menu " + view.getTitleSuffix());
    setSize(800, 600);
    setLocationRelativeTo(null); 
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    pnlTitle = new JPanel(new GridLayout(1, 1));
    pnlTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
    JLabel lblTitle = new JLabel("The Tank Game");
    lblTitle.setFont(new java.awt.Font("Times New Roman", 1, 64));
    lblTitle.setForeground(Color.red);
    
    pnlTitle.add(lblTitle);
    
    pnlButtons = new JPanel(new GridLayout(4, 1));
    pnlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
    
    JButton btnPlay = new JButton("Play");
    btnPlay.setPreferredSize(new Dimension(200, 100));
    btnPlay.addActionListener(event -> play());
    pnlButtons.add(btnPlay);
    
    JButton btnInstructions = new JButton("Instructions");
    btnInstructions.setPreferredSize(new Dimension(200, 100));
    btnInstructions.addActionListener(event -> showInstructions());
    pnlButtons.add(btnInstructions);
    
    JButton btnExit = new JButton("Exit");
    btnExit.setPreferredSize(new Dimension(200, 100));
    btnExit.addActionListener(event -> System.exit(0));
    pnlButtons.add(btnExit);
    
    setContentPane(new JPanel(new BorderLayout()));
    getContentPane().add(pnlTitle, BorderLayout.CENTER);
    getContentPane().add(pnlButtons, BorderLayout.SOUTH);
  }
  
  public void play()
  {
    view.getFrmSelect().setVisible(true);
    this.setVisible(false);
  }
  
  public void showInstructions()
  {
    view.getFrmInstructions().setVisible(true);
    this.setVisible(false);
  }
  
}
