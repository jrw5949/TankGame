
package view;

import java.applet.Applet;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.Timer;
import model.Tank;

public class KeyHandler 
{
    private View view;
    private ImageIcon tankShell;
    public KeyHandler(int key, View view)
    {
        this.view = view;
        JLabel tankLabel = view.frmArena.getTankLabel();
        Tank tank = view.frmArena.getTank();
        if(key == KeyEvent.VK_W)
        {
           tankLabel.setIcon(tank.getImg(1));
           if(tankLabel.getY() <= -15)
           {
               System.out.println("Reached upper boundary");
           }
           else
           {
               tankLabel.setLocation(tankLabel.getX(), tankLabel.getY()-(int)tank.getMaxSpeed());
           }
        }else if(key == KeyEvent.VK_A)
        {
            view.frmArena.getTankLabel().setIcon(view.frmArena.getTank().getImg(2));
            if(tankLabel.getX() <= 0)
            {
                System.out.println("Reached left boundary");
            }
            else
            {
                tankLabel.setLocation(tankLabel.getX()-(int)tank.getMaxSpeed(), tankLabel.getY());
            }
        }else if(key == KeyEvent.VK_S)
        {
            view.frmArena.getTankLabel().setIcon(view.frmArena.getTank().getImg(3));
            if(tankLabel.getY() >= 850)
            {
                System.out.println("Reached lower boundary");
            }
            else
            {
                tankLabel.setLocation(tankLabel.getX(), tankLabel.getY()+(int)tank.getMaxSpeed());
            }
        }else if(key == KeyEvent.VK_D)
        {
            view.frmArena.getTankLabel().setIcon(view.frmArena.getTank().getImg(0));
            if(tankLabel.getX() >= 910)
            {
                System.out.println("Reached right boundary");

            }
            else
            {
                tankLabel.setLocation(tankLabel.getX()+(int)tank.getMaxSpeed(), tankLabel.getY());
            }
        }
        else if(key == KeyEvent.VK_SPACE)
        {
            if(view.frmArena.getTankShell().isVisible() != true)
            {   
                if(view.frmArena.getTankLabel().getIcon() == tank.getImg(0))
                {
                    tankShell = new ImageIcon("./bullets/100.gif");
                    view.frmArena.setTankShell(tankShell);
                    Timer timer = new Timer(10, null);
                    timer.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent ae)
                        {
                            if(view.frmArena.getTankShell().getX() >=910)
                            {
                                timer.stop();
                                view.frmArena.getTankShell().setVisible(false);
                            }else
                            {
                                view.frmArena.getTankShell().setLocation(view.frmArena.getTankShell().getX()+(int)tank.getShutSpeed(), view.frmArena.getTankShell().getY());
                            }
                        }
                    });
                    timer.start();
                    
                }else if(view.frmArena.getTankLabel().getIcon() == tank.getImg(1))
                {
                    tankShell = new ImageIcon("./bullets/200.gif");
                    view.frmArena.setTankShell(tankShell);
                    Timer timer = new Timer(10, null);
                    timer.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent ae)
                        {
                            if(view.frmArena.getTankShell().getY() <=0)
                            {
                                timer.stop();
                                view.frmArena.getTankShell().setVisible(false);
                            }else
                            {
                                view.frmArena.getTankShell().setLocation(view.frmArena.getTankShell().getX(), view.frmArena.getTankShell().getY()-(int)tank.getShutSpeed());
                            }
                        }
                    });
                    timer.start();
                }else if(view.frmArena.getTankLabel().getIcon() == tank.getImg(2))
                {
                    tankShell = new ImageIcon("./bullets/300.gif");
                    view.frmArena.setTankShell(tankShell);
                    Timer timer = new Timer(10, null);
                    timer.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent ae)
                        {
                            if(view.frmArena.getTankShell().getX() <=0)
                            {
                                timer.stop();
                                view.frmArena.getTankShell().setVisible(false);
                            }else
                            {
                                view.frmArena.getTankShell().setLocation(view.frmArena.getTankShell().getX()-(int)tank.getShutSpeed(), view.frmArena.getTankShell().getY());
                            }
                        }
                    });
                    timer.start();
                }else if(view.frmArena.getTankLabel().getIcon() == tank.getImg(3))
                {
                    tankShell = new ImageIcon("./bullets/400.gif");
                    view.frmArena.setTankShell(tankShell);
                    Timer timer = new Timer(10, null);
                    timer.addActionListener(new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent ae)
                        {
                            if(view.frmArena.getTankShell().getY() >=850)
                            {
                                timer.stop();
                                view.frmArena.getTankShell().setVisible(false);
                            }else
                            {
                                view.frmArena.getTankShell().setLocation(view.frmArena.getTankShell().getX(), view.frmArena.getTankShell().getY()+(int)tank.getShutSpeed());
                            }
                        }
                    });
                    timer.start();
                }
            }
            File shot = new File("gunshot.WAV");
            playSound(shot);
        }
    }
    public void playSound(File Sound)
        {
            try
            {
                Clip clip = AudioSystem.getClip();
                clip.open(AudioSystem.getAudioInputStream(Sound));
                clip.start();
                
                Thread.sleep(clip.getMicrosecondLength()/1000);
            }catch(Exception e)
            {
                
            }
        }
}
