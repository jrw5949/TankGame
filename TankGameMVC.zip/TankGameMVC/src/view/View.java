
package view;

import java.util.ArrayList;
import javax.swing.JFrame;
import model.Tank;

public class View extends JFrame
{
  FrmMain frmMain = null;
  FrmInstructions frmInstructions = null;
  FrmSelect frmSelect = null;
  FrmArena frmArena = null;
  private String suffix = " - The Tank Game";

  public View()
  {
      frmMain = new FrmMain(this);
      frmMain.setVisible(true);
      frmSelect = new FrmSelect(this);
      frmArena = new FrmArena(this);
      frmInstructions = new FrmInstructions(this);

    return;
  }

  public FrmMain getFrmMain()
  {
    return frmMain;
  }

  public FrmSelect getFrmSelect()
  {
    return frmSelect;
  }

  public FrmArena getFrmArena()
  {
    return frmArena;
  }

  public FrmInstructions getFrmInstructions()
  {
    return frmInstructions;
  }

  public String getTitleSuffix()
  {
    return suffix;
  }

  public void setUpTanksRowSpecs(ArrayList<Tank> tanks)
  {
    frmSelect.setUpTanksRowSpecs(tanks);
  }
}
