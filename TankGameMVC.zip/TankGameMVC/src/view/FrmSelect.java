
package view;

import java.util.ArrayList;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;

import model.Tank;

class FrmSelect extends JFrame
{
  private View view;
  private JPanel pnlTitle;
  private JPanel pnlSelect;
  private View gp;
  ButtonGroup btgSelect = null;
  private int selectedIndex = 0;
  private Tank selectedTank = null;
  ArrayList<Tank> tanks = null;
  Font font1 = new Font("Times New Roman", 1, 36);
  
  public FrmSelect (View view)
  {
    this.view = view;
    setInitialComponents();
  }
  
  public void setInitialComponents()
  {
    setTitle("Select Tank" + view.getTitleSuffix());
    setSize(1000, 600);
    setLocationRelativeTo(null);  // center the frame
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    JLabel lblTitle = new JLabel("Select Your Tank");
    lblTitle.setFont(new Font("Times New Roman", 1, 64));
    lblTitle.setForeground(Color.red);
    
    pnlTitle = new JPanel(new GridLayout(1, 1));
    pnlTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
    pnlTitle.add(lblTitle);

    btgSelect = new ButtonGroup();
    pnlSelect = new JPanel(new GridLayout(0, 4, 25, 25));
    
    JLabel lblTank = new JLabel("Tank");
    lblTank.setFont(font1);
    pnlSelect.add(lblTank);
    
    JLabel lblSelect = new JLabel("Select");
    lblSelect.setFont(font1);
    pnlSelect.add(lblSelect);
    
    JLabel lblSpeed = new JLabel("Speed");
    lblSpeed.setFont(font1);
    pnlSelect.add(lblSpeed);
    
    JLabel lblShellVel = new JLabel("Shell Velocity");
    lblShellVel.setFont(font1);
    pnlSelect.add(lblShellVel);

    setContentPane(new JPanel(new BorderLayout()));
    getContentPane().add(pnlTitle, BorderLayout.CENTER);
    getContentPane().add(pnlSelect, BorderLayout.SOUTH);
  }
  
  public void setUpTanksRowSpecs(ArrayList<Tank> tanks)
  {
    this.tanks = tanks;
    double doublei = 0;
    Color colori = null;
    JLabel lbli = null;
    Tank tanki = null;    
    selectedTank = tanks.get(0);
    
    JRadioButton[] radName = new JRadioButton[tanks.size()];
    for (int idx=0; idx < tanks.size(); idx++) 
    {
        tanki = tanks.get(idx);
        pnlSelect.add(new JLabel(tanki.getImg(0)));
      
        radName[idx] = new JRadioButton(tanki.getName());
        radName[idx].setFont(font1);
        FrmSelectRadCheckEvent onRandCheck = new FrmSelectRadCheckEvent(this, idx);
        radName[idx].addActionListener(event -> onRandCheck.select());
        btgSelect.add(radName[idx]);
        lbli = new JLabel(tanki.getMaxSpeedq());
        pnlSelect.add(radName[idx]);
        
        lbli.setFont(font1);
        lbli.setForeground(tanki.getSpeedLblColor());
        pnlSelect.add(lbli);
        
        lbli = new JLabel(tanki.getShutSpeedq());
        lbli.setFont(font1);
        lbli.setForeground(tanki.getShutLblColor());
        pnlSelect.add(lbli);
    }
    radName[0].setSelected(true);
        
    JButton bthPlay = new JButton("Play");
    bthPlay.addActionListener(event -> playGame());
    pnlSelect.add(bthPlay);
  }
  
  public void setSelectedIndex(int selectedIndex)
  {
    this.selectedIndex = selectedIndex;
  }

  public void setSelectedTank(Tank selectedTank)
  {
    this.selectedTank = selectedTank;
  }

  public ArrayList<Tank> getTanks()
  {
    return tanks;
  }

  public Tank getSelectedTank()
  {
    return selectedTank;
  }

  public void playGame()
  {     
    this.setVisible(false);
    view.getFrmArena().setupArena(selectedTank);
    view.getFrmArena().setVisible(true);
  }

}
