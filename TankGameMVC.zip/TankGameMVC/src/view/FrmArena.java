
package view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Area;
import javax.swing.ImageIcon;
import model.Tank;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

class FrmArena extends JFrame
{
  private Tank tank = null;
  private JLabel tankLabel = new JLabel();
  private JPanel panel=new JPanel();
  private View view;
  private int time = 30;
  private Timer timer;
  private JLabel tankShell = new JLabel();
  private JLabel enemy1Label = new JLabel();
  private JLabel enemy2Label = new JLabel();
  private JLabel enemy3Label = new JLabel();
  private JLabel enemy1ShellLabel = new JLabel();
  private JLabel enemy2ShellLabel = new JLabel();
  private JLabel enemy3ShellLabel = new JLabel();
  private ImageIcon enemyTankShell = new ImageIcon("./bullets/100.gif");
  private Tank enemy1 = null;
  private Tank enemy2 = null;
  private Tank enemy3 = null;
  private Timer mainTimer = null;

  public FrmArena(View view)
  {
    this.view = view;
    setTitle("Arena - " + view.getTitleSuffix());
    setSize(1000, 1000);
    setLayout(new BorderLayout());
    setContentPane(new JLabel(new ImageIcon("./background.png")));
    setLayout(null);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    tankShell.setBounds(400, 400, 80, 40);
    tankShell.setVisible(false);
    add(tankShell);
    
    addKeyListener(new KeyListener()
    {
        @Override
        public void keyTyped(KeyEvent ke) {
        }

        @Override
        public void keyPressed(KeyEvent ke) {
            int k = ke.getKeyCode();
            KeyHandler keyHandle = new KeyHandler(k, view);
        }

        @Override
        public void keyReleased(KeyEvent ke){
        }
        });
  }
  
  public void setupArena(Tank selectedTank)
  {
    setTank(selectedTank);
    setJLabel();
    addEnemyTanks();
    enemyHitDetection();
    winTest();
    startEnemyShots();
    startTimer();
  }
  
  public void setJLabel()
  {
      tankLabel.setIcon(tank.getImg(0));
      tankLabel.setBounds(400,400,100,100);
      add(tankLabel);
  }
  
  public void startTimer()
  {
      mainTimer = new Timer(1000, null);
      String lossMessage = "You ran out of time, you lost!";
      String tittleLossMessage = "You Lost!";
      mainTimer.addActionListener(new ActionListener()
      {
          @Override
          public void actionPerformed(ActionEvent ae) 
          {
              if(time <= 0)
              {
                  mainTimer.stop();
                  infoBox(lossMessage, tittleLossMessage);
                  System.exit(0);
              }
              else
              {
                time--;
                System.out.println("Time left to destroy all tanks: " + time + " seconds");
              }
          }
      });
      mainTimer.start();
  }
  
  public Timer getMainTimer() 
  {
      return mainTimer;
  }

  public static void infoBox(String infoMessage, String titleBar)
  {
      JOptionPane.showMessageDialog(null, infoMessage,"" + titleBar, JOptionPane.INFORMATION_MESSAGE);
  }

    public Tank getTank() 
    {
        return tank;
    }

  public void setTank(Tank tank)
  {
    this.tank = tank;
  }

    public JLabel getTankLabel() 
    {
        return tankLabel;
    }

    public void setTankShell(ImageIcon img)
    {
        tankShell.setIcon(img);
        tankShell.setLocation(tankLabel.getX(), tankLabel.getY());
        tankShell.setVisible(true);
    }

    public JLabel getTankShell() {
        return tankShell;
    }
    
    public void addEnemyTanks()
    {
        Tank enemy1 = getTank();
        Tank enemy2 = getTank();
        Tank enemy3 = getTank();
        
        enemy1Label.setIcon(enemy1.getImg(0));
        enemy2Label.setIcon(enemy2.getImg(0));
        enemy3Label.setIcon(enemy3.getImg(0));
        
        enemy1Label.setBounds(25, 100, 80, 40);
        enemy2Label.setBounds(25, 500, 80, 40);
        enemy3Label.setBounds(25, 800, 80, 40);
        
        enemy1ShellLabel.setIcon(enemyTankShell);
        enemy2ShellLabel.setIcon(enemyTankShell);
        enemy3ShellLabel.setIcon(enemyTankShell);
        
        enemy1ShellLabel.setBounds(25, 100, 80, 40);
        enemy2ShellLabel.setBounds(25, 500, 80, 40);
        enemy3ShellLabel.setBounds(25, 800, 80, 40);
        
        add(enemy1Label);
        add(enemy2Label);
        add(enemy3Label);
        
        add(enemy1ShellLabel);
        add(enemy2ShellLabel);
        add(enemy3ShellLabel);
    }
    
    public void enemyHitDetection()
    {
        Timer timer1 = new Timer(1, null);
        timer1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(intersects(getTankShell(), getEnemy1Label()) == true)
                {
                    timer1.stop();
                    getEnemy1Label().setVisible(false);
                    getEnemy1ShellLabel().setVisible(false);
                }
            }
        });
        timer1.start();
        
        Timer timer2 = new Timer(1, null);
        timer2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(intersects(getTankShell(), getEnemy2Label()) == true)
                {
                    timer2.stop();
                    getEnemy2Label().setVisible(false);
                    getEnemy2ShellLabel().setVisible(false);
                }
            }
        });
        timer2.start();
        
        Timer timer3 = new Timer(1, null);
        timer3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(intersects(getTankShell(), getEnemy3Label()) == true)
                {
                    timer3.stop();
                    getEnemy3Label().setVisible(false);
                    getEnemy3ShellLabel().setVisible(false);
                }
            }
        });
        timer3.start();
    }
 
    public void winTest()
    {
        Timer timer = new Timer(1, null);
        timer.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(getEnemy1Label().isVisible() == false && getEnemy2Label().isVisible() == false && getEnemy3Label().isVisible() == false && time > 0)
                {
                    timer.stop();
                    getMainTimer().stop();
                    String winTitle = "You Win!";
                    String winMsg = "You have destroyed all tanks before the time ended! You Win!";
                    infoBox(winMsg, winTitle);
                    System.exit(0);
                }
            }
        });
        timer.start();
    }
    
    public boolean intersects(JLabel testa, JLabel testb)
    {
        Area areaA = new Area(testa.getBounds());
        Area areaB = new Area(testb.getBounds());

        return areaA.intersects(areaB.getBounds2D());
    }

    public void startEnemyShots()
    {
        Timer timer1 = new Timer(10, null);
        timer1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(getEnemy1Label().isVisible() == false)
                {
                    timer1.stop();
                    getEnemy1ShellLabel().setVisible(false);
                }
                else if(getEnemy1ShellLabel().isVisible() == true)
                {
                    if(intersects(getEnemy1ShellLabel(),getTankLabel()) == true)
                    {
                        String lossMsg = "You got shot! You Lost!";
                        String lossTitle = "You Lost!";
                        getMainTimer().stop();
                        infoBox(lossMsg, lossTitle);
                        System.exit(0);
                    }else if(getEnemy1ShellLabel().getX() >= 910)
                    {
                        getEnemy1ShellLabel().setVisible(false);
                        resetTank1Shell();
                    }else
                    {
                        getEnemy1ShellLabel().setLocation(getEnemy1ShellLabel().getX() + (int)getTank().getShutSpeed(), getEnemy1ShellLabel().getY());
                    }
                }
                else
                {
                    resetTank1Shell();
                }
            }
            
        });
        timer1.start();
        
        Timer timer2 = new Timer(10, null);
        timer2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(getEnemy2Label().isVisible() == false)
                {
                    timer2.stop();
                    getEnemy2ShellLabel().setVisible(false);
                }
                else if(getEnemy2ShellLabel().isVisible() == true)
                {
                    if(intersects(getEnemy2ShellLabel(),getTankLabel()) == true)
                    {
                        String lossMsg = "You got shot! You Lost!";
                        String lossTitle = "You Lost!";
                        getMainTimer().stop();
                        infoBox(lossMsg, lossTitle);
                        System.exit(0);
                    }else if(getEnemy2ShellLabel().getX() >= 910)
                    {
                        getEnemy2ShellLabel().setVisible(false);
                        resetTank2Shell();
                    }else
                    {
                        getEnemy2ShellLabel().setLocation(getEnemy2ShellLabel().getX() + (int)getTank().getShutSpeed(), getEnemy2ShellLabel().getY());
                    }
                }
                else
                {
                    resetTank2Shell();
                }
            }
            
        });
        timer2.start();
        
        Timer timer3 = new Timer(10, null);
        timer3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
                if(getEnemy3Label().isVisible() == false)
                {
                    timer3.stop();
                    getEnemy3ShellLabel().setVisible(false);
                }
                else if(getEnemy3ShellLabel().isVisible() == true)
                {
                    if(intersects(getEnemy3ShellLabel(),getTankLabel()) == true)
                    {
                        String lossMsg = "You got shot! You Lost!";
                        String lossTitle = "You Lost!";
                        getMainTimer().stop();
                        infoBox(lossMsg, lossTitle);
                        System.exit(0);
                    }else if(getEnemy3ShellLabel().getX() >= 910)
                    {
                        getEnemy3ShellLabel().setVisible(false);
                        resetTank3Shell();
                    }else
                    {
                        getEnemy3ShellLabel().setLocation(getEnemy3ShellLabel().getX() + (int)getTank().getShutSpeed(), getEnemy3ShellLabel().getY());
                    }
                }
                else
                {
                    resetTank3Shell();
                }
            }
            
        });
        timer3.start();
    }
    
    public void resetTank1Shell()
    {
        getEnemy1ShellLabel().setLocation(getEnemy1Label().getX(), getEnemy1Label().getY());
        getEnemy1ShellLabel().setVisible(true);
    }
    
    public void resetTank2Shell()
    {
        getEnemy2ShellLabel().setLocation(getEnemy2Label().getX(), getEnemy2Label().getY());
        getEnemy2ShellLabel().setVisible(true);
    }
    
    public void resetTank3Shell()
    {
        getEnemy3ShellLabel().setLocation(getEnemy3Label().getX(), getEnemy3Label().getY());
        getEnemy3ShellLabel().setVisible(true);
    }
    
    public JLabel getEnemy1Label() {
        return enemy1Label;
    }

    public JLabel getEnemy2Label() {
        return enemy2Label;
    }

    public JLabel getEnemy3Label() {
        return enemy3Label;
    }

    public JLabel getEnemy1ShellLabel() {
        return enemy1ShellLabel;
    }

    public JLabel getEnemy2ShellLabel() {
        return enemy2ShellLabel;
    }

    public JLabel getEnemy3ShellLabel() {
        return enemy3ShellLabel;
    }

    public Tank getEnemy1() {
        return enemy1;
    }

    public Tank getEnemy2() {
        return enemy2;
    }

    public Tank getEnemy3() {
        return enemy3;
    }    
}