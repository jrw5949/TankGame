
package controller;

import model.Model;
import view.View;

public class Controller 
{

  Model model = null;    
  View view = null;    

  public Controller(Model model, View view)
  {
    this.model = model;
    this.view = view;
    view.setUpTanksRowSpecs(model.getTanksSpecs());
  }

}
