package tankgame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InstructionsMenu extends JFrame
{
    private JPanel topPanel;
    private JPanel buttonPanel;
    private Controller ctnl;
    
    public InstructionsMenu(Controller ctnl)
    {
        this.ctnl = ctnl;
        intComponents();
    }
    
    private void intComponents()
    {
        setTitle("Instructions");
        setSize(500, 500);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel one = new JLabel("W - Move tank up");
        JLabel two = new JLabel("A - Move tank down");
        JLabel three = new JLabel("S - Move tank left");
        JLabel four = new JLabel("D - Move tank right");
        JLabel five = new JLabel("SPACE - Shoot");
        one.setFont(new java.awt.Font("Times New Roman", 1, 36));
        two.setFont(new java.awt.Font("Times New Roman", 1, 36));
        three.setFont(new java.awt.Font("Times New Roman", 1, 36));
        four.setFont(new java.awt.Font("Times New Roman", 1, 36));
        five.setFont(new java.awt.Font("Times New Roman", 1, 36));
        topPanel = new JPanel(new GridLayout(5, 1));
        topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        topPanel.add(one);
        topPanel.add(two);
        topPanel.add(three);
        topPanel.add(four);
        topPanel.add(five);
        
        buttonPanel = new JPanel(new GridLayout(1, 1));
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        JButton play = new JButton("Back to main menu");
        play.setPreferredSize(new Dimension(200, 100));
        play.addActionListener(event -> ctnl.instructionsBack());
        buttonPanel.add(play);
        
        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(topPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }
}
