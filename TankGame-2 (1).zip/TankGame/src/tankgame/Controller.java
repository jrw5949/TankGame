package tankgame;

import javax.swing.ImageIcon;

public class Controller 
{
    private Model model;
    private MainMenu view;
    
    public Controller()
    {
        model = new Model(this);
        view = new MainMenu(this);
        view.setVisible(true);
    }
    
    public void instructionsBack()
    {
        view.instructionsBack();
    }
    
    public void tank1()
    {
        model.tank1();
    }
    
    public void tank2()
    {
        model.tank2();
    }
    public void tank3()
    {
        model.tank3();
    }
    public void tank4()
    {
        model.tank4();
    }

    public ImageIcon getTankc()
    {
        ImageIcon tank = new ImageIcon();
        tank = model.getTank();
        return tank;
    }
    
    public void keyPressedc(int key, View gp)
    {
       model.tankControls(key, gp); // Send the key and view from View into the model to deal with WASD movment and shooting
    }
}
