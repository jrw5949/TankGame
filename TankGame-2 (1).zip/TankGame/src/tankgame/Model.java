package tankgame;

import com.sun.glass.events.KeyEvent;
import javax.swing.ImageIcon;

public class Model 
{
    private Controller ctnl;
    private MainMenu mainMenu;
    private InstructionsMenu instructions;
    private View view;
    private String tankName = "Hotchkiss";
    private ImageIcon tank = new ImageIcon("./Hotchkiss/100.gif");
    private ImageIcon HotchkissR = new ImageIcon("./Hotchkiss/100.gif");
    private ImageIcon PantherR = new ImageIcon("./Panther/100.gif");
    private ImageIcon T34R = new ImageIcon("./T_34/100.gif");
    private ImageIcon PanzerVIR = new ImageIcon("./PanzerVI/100.gif");
    private ImageIcon HotchkissU = new ImageIcon("./Hotchkiss/200.gif");
    private ImageIcon PantherU = new ImageIcon("./Panther/200.gif");
    private ImageIcon T34U = new ImageIcon("./T_34/200.gif");
    private ImageIcon PanzerVIU = new ImageIcon("./PanzerVI/200.gif");
    private ImageIcon HotchkissL = new ImageIcon("./Hotchkiss/300.gif");
    private ImageIcon PantherL = new ImageIcon("./Panther/300.gif");
    private ImageIcon T34L = new ImageIcon("./T_34/300.gif");
    private ImageIcon PanzerVIL = new ImageIcon("./PanzerVI/300.gif");
    private ImageIcon HotchkissD = new ImageIcon("./Hotchkiss/400.gif");
    private ImageIcon PantherD = new ImageIcon("./Panther/400.gif");
    private ImageIcon T34D = new ImageIcon("./T_34/400.gif");
    private ImageIcon PanzerVID = new ImageIcon("./PanzerVI/400.gif");
    
    public Model(Controller ctnl)
    {
        this.ctnl = ctnl;
    }
    
    public void tank1()
    {
        tank = HotchkissR;
        tankName = "Hotchkiss";
    }
    
    public void tank2()
    {
        tank = PantherR;
        tankName = "Panther";
    }
    
    public void tank3()
    {
        tank = T34R;
        tankName = "T-34";
    }
    
    public void tank4()
    {
        tank = PanzerVIR;
        tankName = "PanzerVI";
    }

    public ImageIcon getTank() 
    {
        return tank;
    }    
    
    public String getTankName()
    {
        return tankName;
    }
    
    public void tankControls(int key, View view) // The example of at least one round trip information path from viewer to controller to model and back
    {
        if(key == KeyEvent.VK_W)
        {
            if(getTankName().equals("Hotchkiss"))
            {
               view.getTank().setIcon(HotchkissU);
               view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-6); // changes the view to update based on movment recorded.
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherU);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-2);
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34U);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-4);
            }
            else
            {
                view.getTank().setIcon(PanzerVIU);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-3);
            }
        }
        else if(key == KeyEvent.VK_A)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                view.getTank().setIcon(HotchkissL);
                view.getTank().setLocation(view.getTank().getX()-6, view.getTank().getY());
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherL);
                view.getTank().setLocation(view.getTank().getX()-2, view.getTank().getY());
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34L);
                view.getTank().setLocation(view.getTank().getX()-4, view.getTank().getY());
            }
            else
            {
                view.getTank().setIcon(PanzerVIL);
                view.getTank().setLocation(view.getTank().getX()-3, view.getTank().getY());
            }
        }
        else if(key == KeyEvent.VK_S)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                view.getTank().setIcon(HotchkissD);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+6);
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherD);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+2);
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34D);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+4);
            }
            else
            {
                view.getTank().setIcon(PanzerVID);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+3);
            }
        }
        else if(key == KeyEvent.VK_D)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                view.getTank().setIcon(HotchkissR);
                view.getTank().setLocation(view.getTank().getX()+6, view.getTank().getY());
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherR);
                view.getTank().setLocation(view.getTank().getX()+2, view.getTank().getY());
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34R);
                view.getTank().setLocation(view.getTank().getX()+4, view.getTank().getY());
            }
            else
            {
                view.getTank().setIcon(PanzerVIR);
                view.getTank().setLocation(view.getTank().getX()+3, view.getTank().getY());
            }
        }
        else if(key == KeyEvent.VK_SPACE)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                System.out.println("SHOOT");
            }
            else if(getTank().equals("Panther"))
            {
                System.out.println("SHOOT");
            }
            else if(getTankName().equals("T-34"))
            {
                System.out.println("SHOOT");
            }
            else
            {
                System.out.println("SHOOT");
            }
        }
    }
}
