// Jake White
// jrw5949
// Functionality/Testing
// When program start you should see a main menu with three buttons, "Play", "Instructions", and "Exit"
// "Play" should make main menu disapear and pop up the Tank selection menu
// "Instructions" should pop up the game instructions page with a "back" button that brings you back to the main menu
// "Exit" should exit the program
// The tank selection screen should show the 4 tanks and have radio buttons next to them that the user can select their tank
// The tank selection screen also has a play buttton that launches the first level when the play button is hit with the according tank picked
// The level1 screen should have your tank and you should be able to move it using WASD and when spacebar is pressed "shoot" is printed
// Acording to what tank you picked the tank will move faster or slower baised on the stats on the tank selection screen.

/*
Promised delivery 2 items included:

A new UI menu in which the player can select the type of tank they want to use. It will also include basic movement of the players tank 
using WASD movement. 

To add this new functionality I will need to add another UI class called tankScreen where the player can select from multiple tanks.

This UI page will need from one to four JButtons, one to four JLabels, and one to four pictures of the tanks.

JButton to play the first level

The play screen will need an image of the players tank and I will need to add the WASD movement to my user input. This will track 
keystrokes and correspond the correct control.

My new tank selection screen will have four tank images and a JLabel on top or next to the tanks indicating their names.

It will have buttons next to each image in which the user can select. This is how a user will choose their tank.
*/

package tankgame;

public class TankGame 
{
    public static void main(String[] args) 
    {
        Controller ctnl = new Controller();
    }
}
