
package tankgame;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class View extends JFrame
{
    private Controller ctnl;
    private View view;
    private JLabel tank = null;
     
    public View(Controller ctnl)
    {
        this.ctnl = ctnl;
        view = this;
        intComponents();
        addKeyListener(new KeyListener()
        {
            @Override
            public void keyPressed(KeyEvent ke) //demonstration of at least one round trip information path from viewer to controller to model
            {
                int k = ke.getKeyCode();
                ctnl.keyPressedc(k, view); // sends key pressed and view into controller
            }

            @Override
            public void keyTyped(KeyEvent ke) {
            }

            @Override
            public void keyReleased(KeyEvent ke) {
            }
        });
    }
    
    private void intComponents()
    {
        setTitle("Level 1");
        setSize(1000, 1000);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel=new JPanel();
        getContentPane().add(panel);
        panel.setLayout(null);
        ImageIcon tankSelected = ctnl.getTankc();
        tank = new JLabel(tankSelected);
        tank.setBounds(400,400,100,50);
        tank.setSize(100,100);
        panel.add(tank);  
    }

    public JLabel getTank() 
    {
        return tank;
    }   
}
