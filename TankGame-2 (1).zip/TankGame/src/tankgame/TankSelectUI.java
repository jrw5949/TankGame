
package tankgame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class TankSelectUI extends JFrame
{
    private JPanel tankSelectionTitle;
    private JPanel tankSelection;
    private View gp;
    private Controller ctnl;
    private Image Hotchkiss;
    private Image Panther;
    private Image T34;
    private Image PanzerVI;
    
    public TankSelectUI (Controller ctnl)
    {
        this.ctnl = ctnl;
        intComponents();
    }
    
    public void intComponents()
    {
        ImageIcon Hotchkiss = new ImageIcon("./Hotchkiss/100.gif");
        ImageIcon Panther = new ImageIcon("./Panther/100.gif");
        ImageIcon T34 = new ImageIcon("./T_34/100.gif");
        ImageIcon PanzerVI = new ImageIcon("./PanzerVI/100.gif");
        
        setTitle("The Tank Game");
        setSize(1000, 500);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        tankSelectionTitle = new JPanel(new GridLayout(1, 1));
        tankSelectionTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        
        JLabel title = new JLabel("Select Your Tank");
        title.setFont(new java.awt.Font("Times New Roman", 1, 64));
        title.setForeground(Color.red);
        
        tankSelectionTitle.add(title);
        ButtonGroup G = new ButtonGroup();
        tankSelection = new JPanel(new GridLayout(0, 4, 25, 25));
        
        JLabel tank = new JLabel("Tank");
        tank.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tankSelection.add(tank);
        
        JLabel select = new JLabel("Select");
        select.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tankSelection.add(select);
        
        JLabel speed = new JLabel("Speed");
        speed.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tankSelection.add(speed);
        
        JLabel shellVel = new JLabel("Shell Velocity");
        shellVel.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tankSelection.add(shellVel);
        
        // UI for Hotchkiss
        JLabel hotchkiss = new JLabel(Hotchkiss);
        tankSelection.add(hotchkiss);
        
        JRadioButton tank1 = new JRadioButton("Hotchkiss");
        tank1.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank1.setSelected(true);
        tank1.addActionListener(event -> ctnl.tank1());
        tankSelection.add(tank1);
        
        JLabel tank1Speed = new JLabel("Fast");
        tank1Speed.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank1Speed.setForeground(Color.green);
        tankSelection.add(tank1Speed);
        
        JLabel tank1Vel = new JLabel("Slow");
        tank1Vel.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank1Vel.setForeground(Color.red);
        tankSelection.add(tank1Vel);
        
        // UI for Panther
        JLabel panther = new JLabel(Panther);
        tankSelection.add(panther);
        
        JRadioButton tank2 = new JRadioButton("Panther");
        tank2.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank2.addActionListener(event -> ctnl.tank2());
        tankSelection.add(tank2);
        
        JLabel tank2Speed = new JLabel("Slow");
        tank2Speed.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank2Speed.setForeground(Color.red);
        tankSelection.add(tank2Speed);
        
        JLabel tank2Vel = new JLabel("Fast");
        tank2Vel.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank2Vel.setForeground(Color.green);
        tankSelection.add(tank2Vel);
        
        // UI for T34
        JLabel t34 = new JLabel(T34);
        tankSelection.add(t34);
        
        JRadioButton tank3 = new JRadioButton("T-34");
        tank3.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank3.addActionListener(event -> ctnl.tank3());
        tankSelection.add(tank3);
        
        JLabel tank3Speed = new JLabel("Medium");
        tank3Speed.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank3Speed.setForeground(Color.orange);
        tankSelection.add(tank3Speed);
        
        JLabel tank3Vel = new JLabel("Medium");
        tank3Vel.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank3Vel.setForeground(Color.orange);
        tankSelection.add(tank3Vel);
        
        // UI for Panzer VI
        JLabel panzerVI = new JLabel(PanzerVI);
        tankSelection.add(panzerVI);
        
        JRadioButton tank4 = new JRadioButton("Panzer VI");
        tank4.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank4.addActionListener(event -> ctnl.tank4());
        tankSelection.add(tank4);
        
        JLabel tank4Speed = new JLabel("Medium-Slow");
        tank4Speed.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank4Speed.setForeground(Color.yellow);
        tankSelection.add(tank4Speed);
        
        JLabel tank4Vel = new JLabel("Medium-Fast");
        tank4Vel.setFont(new java.awt.Font("Times New Roman", 1, 36));
        tank4Vel.setForeground(Color.yellow);
        tankSelection.add(tank4Vel);
        
        
        JButton play = new JButton("Play");
        play.addActionListener(event -> playGame());
        tankSelection.add(play);
        
        
        G.add(tank1);
        G.add(tank2);
        G.add(tank3);
        G.add(tank4);
        
        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(tankSelectionTitle, BorderLayout.CENTER);
        getContentPane().add(tankSelection, BorderLayout.SOUTH);
    }
    
    public void playGame()
    {
        gp = new View(ctnl);
        gp.setVisible(true);
        this.setVisible(false);
    }
}
