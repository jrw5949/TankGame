
package model;

//----------------------------------------------------------------------
public class TTank
{
  protected String name = "T-34";
  protected double maxSpeed = 5;
  protected double shutSpeed = 5;
  protected String maxSpeedq = "Medium";
  protected String shutSpeedq = "Medium";

  public TTank(){
    return;
  }

  public TTank(String name){
    return;
  }

  public TTank(
    String name
  , double maxSpeed
  , double shutSpeed
  ){
    this.maxSpeed = maxSpeed;
    this.shutSpeed = shutSpeed;
    this.name = name;
    return;
  }//TTank.end

  public String getName()
  {
    return name;
  }

  public double getMaxSpeed()
  {
    return maxSpeed;
  }

  public double getShutSpeed()
  {
    return shutSpeed;
  }

  public String getMaxSpeedq()
  {
    return maxSpeedq;
  }

  public String getShutSpeedq()
  {
    return shutSpeedq;
  }

  public void setName(String name)
  {
    this.name = name;
    return;
  }

  
  public void setMaxSpeed(double maxSpeed)
  {
    this.maxSpeed = maxSpeed;
    return;
  }

  public void setShutSpeed(double shutSpeed)
  {
    this.shutSpeed = shutSpeed;
    return;
  }

  public void setMaxSpeedq(String maxSpeedq)
  {
    this.maxSpeedq = maxSpeedq;
    return;
  }

  public void setShutSpeedq(String shutSpeedq)
  {
    this.shutSpeedq = shutSpeedq;
    return;
  }

  public void printInfo()
  {
    System.out.printf(""
    + "%n---------------------------------------------"
    + "%nname      : %s"
    + "%nmaxSpeed  : %1.2f"
    + "%nshutSpeed : %1.2f"
    , name, maxSpeed, shutSpeed
    );
    return;
  }

  public static void main(String[] args) {
    TTank  panther = new TTank("Panther", 15, 50);
    panther.printInfo();
    System.out.println();
    return;
  }

  public static void printInfoHere(String msg) 
  {
    System.out.print("\n---------------------------------------------");
    String fullClassName = Thread.currentThread().getStackTrace()[2].getClassName();
    String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
    String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
    int lineNumber = Thread.currentThread().getStackTrace()[2].getLineNumber();

    System.out.print(
    "\n"+ className + "." + methodName + "():" + lineNumber
    );
    System.out.print("\n--- " + msg);

    return;
  }

}
