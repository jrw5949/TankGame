
package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Dimension;

class FrmInstructions extends JFrame
{
  private JPanel pnlTop;
  private JPanel pnlMoveKeys;
  private View view;
  
  public FrmInstructions(View view)
  {
    this.view = view;
    intComponents();
  }
  
  private void intComponents()
  {
    Font font1 = new Font("Times New Roman", 1, 36);

    setTitle("Instructions " + view.getTitleSuffix());
    setSize(500, 500);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    pnlTop = new JPanel(new GridLayout(5, 1));//???
    pnlTop = new JPanel(new FlowLayout(FlowLayout.CENTER));//???
    pnlTop = new JPanel(new FlowLayout(FlowLayout.CENTER));
    
    JLabel lblK1 = new JLabel("W - Move tank up");
    lblK1.setFont(font1);
    pnlTop.add(lblK1);

    JLabel lblK2 = new JLabel("A - Move tank down");
    lblK2.setFont(font1);
    pnlTop.add(lblK2);

    JLabel lblK3 = new JLabel("S - Move tank left");
    lblK3.setFont(font1);
    pnlTop.add(lblK3);

    JLabel lblK4 = new JLabel("D - Move tank right");
    lblK4.setFont(font1);
    pnlTop.add(lblK4);

    JLabel lblK5 = new JLabel("SPACE - Shoot");
    lblK5.setFont(font1);
    pnlTop.add(lblK5);
    
    pnlMoveKeys = new JPanel(new GridLayout(1, 1));//???
    pnlMoveKeys = new JPanel(new FlowLayout(FlowLayout.CENTER));
    
    JButton btnPlay = new JButton("Back to main menu");
    btnPlay.setPreferredSize(new Dimension(200, 100));
    btnPlay.addActionListener(event -> goBack());
    pnlMoveKeys.add(btnPlay);
    
    setContentPane(new JPanel(new BorderLayout()));
    getContentPane().add(pnlTop, BorderLayout.CENTER);
    getContentPane().add(pnlMoveKeys, BorderLayout.SOUTH);
  }

  public void goBack()
  {
    view.getFrmMain().setVisible(true);
    this.setVisible(false);
  }

}
