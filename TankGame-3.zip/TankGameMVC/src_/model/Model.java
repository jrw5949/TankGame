
// package tankgame;

import com.sun.glass.events.KeyEvent;
import javax.swing.ImageIcon;
import java.util.ArrayList;

public class Model 
{
    private Controller ctnl;
    private MainMenuScreen mainMenu;
    private FrmInstructions instructions;
    private View view;
    // private ArrayList<ImageIcon> xxx = new ArrayList<ImageIcon>();// temp....

    private String tankName = "Hotchkiss";
    private ImageIcon tank = new ImageIcon("./tanks/Hotchkiss/100.gif");

    private Tank hotchkiss = new Tank("Hotchkiss", 5, 5, "./tanks/Hotchkiss");
    ArrayList<ImageIcon> alimg1 = hotchkiss.getImg();
    private ImageIcon HotchkissR = alimg1.get(0);
    private ImageIcon HotchkissU = alimg1.get(1);
    private ImageIcon HotchkissL = alimg1.get(2);
    private ImageIcon HotchkissD = alimg1.get(3);

    private Tank panther = new Tank("Panther", 2, 5, "./tanks/Panther");
    ArrayList<ImageIcon> alimg2 = panther.getImg();
    private ImageIcon PantherR = alimg2.get(0);
    private ImageIcon PantherU = alimg2.get(1);
    private ImageIcon PantherL = alimg2.get(2);
    private ImageIcon PantherD = alimg2.get(3);

    private Tank t34 = new Tank("T-34", 4, 5, "./tanks/T-34");
    ArrayList<ImageIcon> alimg3 = t34.getImg();
    private ImageIcon T34R = alimg3.get(0);
    private ImageIcon T34U = alimg3.get(1);
    private ImageIcon T34L = alimg3.get(2);
    private ImageIcon T34D = alimg3.get(3);

    private Tank panzervi = new Tank("Panzer VI", 3, 5, "./tanks/PanzerVI");
    ArrayList<ImageIcon> alimg4 = panzervi.getImg();
    private ImageIcon PanzerVIR = alimg4.get(0);
    private ImageIcon PanzerVIU = alimg4.get(1);
    private ImageIcon PanzerVIL = alimg4.get(2);
    private ImageIcon PanzerVID = alimg4.get(3);
    

    public void tank1()
    {
        tank = t34.getImg().get(0);
        tankName = "Hotchkiss";
    }
    
    public void tank2()
    {
        tank = t34.getImg().get(0);
        tankName = "Panther";
    }
    
    public void tank3()
    {
        tank = t34.getImg().get(0);
        tankName = "T-34";
    }
    
    public void tank4()
    {
        tank = t34.getImg().get(0);
        tankName = "PanzerVI";
    }

    public ImageIcon getTank() 
    {
        return tank;
    }    
    
    public String getTankName()
    {
        return tankName;
    }
    
    public void tankControls(int key, View view) // The example of at least one round trip information path from viewer to controller to model and back
    {
        if(key == KeyEvent.VK_W)
        {
            if(getTankName().equals("Hotchkiss"))
            {
               view.getTank().setIcon(HotchkissU);
               view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-6); // changes the view to update based on movment recorded.
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherU);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-2);
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34U);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-4);
            }
            else
            {
                view.getTank().setIcon(PanzerVIU);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()-3);
            }
        }
        else if(key == KeyEvent.VK_A)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                view.getTank().setIcon(HotchkissL);
                view.getTank().setLocation(view.getTank().getX()-6, view.getTank().getY());
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherL);
                view.getTank().setLocation(view.getTank().getX()-2, view.getTank().getY());
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34L);
                view.getTank().setLocation(view.getTank().getX()-4, view.getTank().getY());
            }
            else
            {
                view.getTank().setIcon(PanzerVIL);
                view.getTank().setLocation(view.getTank().getX()-3, view.getTank().getY());
            }
        }
        else if(key == KeyEvent.VK_S)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                view.getTank().setIcon(HotchkissD);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+6);
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherD);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+2);
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34D);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+4);
            }
            else
            {
                view.getTank().setIcon(PanzerVID);
                view.getTank().setLocation(view.getTank().getX(), view.getTank().getY()+3);
            }
        }
        else if(key == KeyEvent.VK_D)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                view.getTank().setIcon(HotchkissR);
                view.getTank().setLocation(view.getTank().getX()+6, view.getTank().getY());
            }
            else if(getTankName().equals("Panther"))
            {
                view.getTank().setIcon(PantherR);
                view.getTank().setLocation(view.getTank().getX()+2, view.getTank().getY());
            }
            else if(getTankName().equals("T-34"))
            {
                view.getTank().setIcon(T34R);
                view.getTank().setLocation(view.getTank().getX()+4, view.getTank().getY());
            }
            else
            {
                view.getTank().setIcon(PanzerVIR);
                view.getTank().setLocation(view.getTank().getX()+3, view.getTank().getY());
            }
        }
        else if(key == KeyEvent.VK_SPACE)
        {
            if(getTankName().equals("Hotchkiss"))
            {
                System.out.println("SHOOT");
            }
            else if(getTank().equals("Panther"))
            {
                System.out.println("SHOOT");
            }
            else if(getTankName().equals("T-34"))
            {
                System.out.println("SHOOT");
            }
            else
            {
                System.out.println("SHOOT");
            }
        }
    }
}
