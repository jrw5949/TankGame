
package view;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class View extends JFrame
{
    private Controller ctnl;
    private View view;
    private JLabel tank = null;
     
    public View(Controller ctnl)
    {
        this.ctnl = ctnl;
        view = this;

        addKeyListener(new KeyListener()
        {
            @Override
            public void keyPressed(KeyEvent ke) //demonstration of at least one round trip information path from viewer to controller to model
            {
                int k = ke.getKeyCode();
                ctnl.keyPressedc(k, view); // sends key pressed and view into controller
            }

            @Override
            public void keyTyped(KeyEvent ke) {
            }

            @Override
            public void keyReleased(KeyEvent ke) {
            }
        });
    }
    
    public JLabel getTank() 
    {
        return tank;
    }   
}



