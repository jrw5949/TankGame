package tankgame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class View extends JFrame
{
    private JPanel topPanel;
    private JPanel buttonPanel;
    private Controller ctnl;
    
    public View(Controller ctnl)
    {
        this.ctnl = ctnl;
        initComponents();
    }
    
    private void initComponents() 
    {
        setTitle("The Tank Game");
        setSize(800, 600);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        topPanel = new JPanel(new GridLayout(1, 1));
        topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        
        JLabel title = new JLabel("The Tank Game");
        title.setFont(new java.awt.Font("Times New Roman", 1, 64));
        title.setForeground(Color.red);
        
        topPanel.add(title);
        
        buttonPanel = new JPanel(new GridLayout(4, 1));
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        JButton play = new JButton("Play");
        play.setPreferredSize(new Dimension(200, 100));
        play.addActionListener(event -> ctnl.Play());
        buttonPanel.add(play);
        
        JButton instructions = new JButton("Instructions");
        instructions.setPreferredSize(new Dimension(200, 100));
        instructions.addActionListener(event -> ctnl.Instructions());
        buttonPanel.add(instructions);
        
        JButton exit = new JButton("Exit");
        exit.setPreferredSize(new Dimension(200, 100));
        exit.addActionListener(event -> ctnl.Exit());
        buttonPanel.add(exit);
        
        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(topPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }
}
