
package tankgame;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class gamePanel extends JFrame
{
    private Controller ctnl;
     
    public gamePanel(Controller ctnl)
    {
        this.ctnl = ctnl;
        intComponents();
    }
    
    private void intComponents()
    {
        setTitle("Level 1");
        setSize(1000, 1000);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setContentPane(new JPanel(new BorderLayout()));
    }
}
