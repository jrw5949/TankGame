package tankgame;

public class Model 
{
    private Controller ctnl;
    private View view;
    private Instructions instructions;
    private gamePanel gp;
    
    public Model(Controller ctnl)
    {
        this.ctnl = ctnl;
        
    }
    
    public void ExitM()
    {
        System.exit(0);
    }
    
    public void Play()
    {
        gp = new gamePanel(ctnl);
        gp.setVisible(true);
        ctnl.setMenuVisF();
    }
    
    public void Instructions()
    {
        instructions = new Instructions(ctnl);
        ctnl.setMenuVisF();
        instructions.setVisible(true);
    }
    
    public void instructionsBack()
    {
        instructions.setVisible(false);
        ctnl.setMenuVisT();
    }
}
