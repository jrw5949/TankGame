// Jake White
// jrw5949

package tankgame;

public class TankGame 
{
    public static void main(String[] args) 
    {
        Controller ctnl = new Controller();
    }
}
