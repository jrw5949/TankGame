package tankgame;

public class Controller 
{
    private Model model;
    private View view;
    
    public Controller()
    {
        model = new Model(this);
        view = new View(this);
        view.setVisible(true);
    }
    
    public void Play()
    {
        model.Play();
    }
    
    public void Instructions()
    {
        model.Instructions();
    }
    
    public void Exit()
    {
        model.ExitM();
    }
    
    public void instructionsBack()
    {
        model.instructionsBack();
    }
    
    public void setMenuVisF()
    {
        view.setVisible(false);
    }
    
    public void setMenuVisT()
    {
        view.setVisible(true);
    }
}
